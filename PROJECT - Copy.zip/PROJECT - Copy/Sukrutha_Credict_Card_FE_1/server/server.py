from twilio.rest import Client
import socket
import yagmail
import time
import pandas as pd
from attack_prediction import attack_predict
from lib_file import lib_path
from datetime import datetime
from io import BytesIO

ip_address = socket.gethostbyname(socket.gethostname())
port = 5005

print("-------------------------------------")
print("[STARTED]  > Server running at : ", ip_address, " ", port)
print()

s = socket.socket()
s.bind((ip_address, port))
s.listen(5)

print("[LISTENING] > Waiting for connection ..")


def insert_into_payment(file, payment_date, file_name, email, amount, payment,
                        card_name, card_number, card_date, card_cvv, upi_name, upi_id):
    r2 = pd.read_excel(file)

    # Calculate the difference between the current amount and the previous total_amount
    total_amount = 100000  # Default total_amount
    if not r2.empty:
        total_amount = r2['total_amount'].iloc[-1] - amount

    # Insert the new row with provided values
    new_row = pd.Series({
        "payment_date": payment_date,
        "file_name": file_name,
        "email": email,
        "amount": amount,
        "payment": payment,
        "card_name": card_name,
        "card_number": card_number,
        "card_date": card_date,
        "card_cvv": card_cvv,
        "upi_name": upi_name,
        "upi_id": upi_id,
        "total_amount": total_amount
    })

    r2 = pd.concat([r2, new_row.to_frame().T], ignore_index=True)
    r2.to_excel(file, index=False)


def insert_into_excel(file, address, res):
    print("Open : insert_into_excel")
    date = datetime.today()
    r2 = pd.read_excel(file)
    new_row = [date, address, res]
    r2.loc[-1] = new_row
    r2 = r2.reset_index(drop=True)
    r2.to_excel(file, index=False)


def check_ser_card_no(card_number):
    print("Open :  check_ser_card_no")
    print("card_number : ", card_number)
    excel_file_path = 'payment_server.xlsx'
    df_server = pd.read_excel(excel_file_path)
    card_numbers_in_file = df_server['card_number'].tolist()
    before_card_status = df_server['status'].tolist()

    print("Card numbers in file: ", card_numbers_in_file)
    print("before_card_status : ", before_card_status)

    if card_number in card_numbers_in_file:
        print("Card number matched!")
        return True
    else:
        print("Card number not found in the file.")
        return False


def check_ser_upi_id(upi_id):
    print("Open :  check_ser_upi_id")
    print("upi_id : ", upi_id)
    excel_file_path = 'payment_server.xlsx'
    df_server = pd.read_excel(excel_file_path)
    upi_id_in_file = df_server['upi_id'].tolist()
    before_upi_status = df_server['status'].tolist()

    print("upi id in file: ", upi_id_in_file)
    print("before_upi_status: ", before_upi_status)

    if upi_id in upi_id_in_file:
        print("upi id matched!")
        return True
    else:
        print("upi id not found in the file.")
        return False


def sendmail(phone_number, result, account_status):
    print('sendmail is opened')
    print('phone_number:', phone_number)
    print('result:', result)
    print('account_status:', account_status)
    try:
        account_sid = 'ACca4f0780cc435075ed35f0847cd76408'
        auth_token = '6f0300a8d1837be965ddd451a70cc755'
        twilio_phone_number = '+12516470370'
        client = Client(account_sid, auth_token)
        to_phone_number = phone_number
        message_body = f'The prediction result is: {result}. \n {account_status}.'
        message = client.messages.create(
            body=message_body,
            from_=twilio_phone_number,
            to=to_phone_number
        )
        print(f'Message sent successfully to : {phone_number}')

    except Exception as e:
        print('[FAILED] >', e)
        return "failed"


card_number = ""
upi_id = ""


def card_no_status(email, card_number, result):
    excel_file_path = 'payment_server.xlsx'
    df_server = pd.read_excel(excel_file_path)

    print("card_number : ", card_number)

    # Update the 'status' column based on the condition and specific card_number
    mask = df_server['card_number'] == card_number
    print("card_mask : ", mask)

    if result == 'Benign':
        if df_server.loc[mask, 'status'].iloc[0] == 'Active':
            current_card_status = df_server['status'].tolist()
            print("Updated card_status: ", current_card_status)

            account_status = f"Card Status Update - {card_number}. \n The card status for {card_number} is now Active."
            mail = sendmail(email, result, account_status)
            # print("email_id : ", email)
            # print("mail : ", mail)
        
        elif df_server.loc[mask, 'status'].iloc[0] == 'Blocked':
            current_card_status = df_server['status'].tolist()
            print("Updated card_status: ", current_card_status)

            account_status = f"Card Status Update - {card_number}. \n The card status for {card_number} is now Blocked."
            mail = sendmail(email, result, account_status)
            # print("email_id : ", email)
            # print("mail : ", mail)

    else:
        df_server.loc[mask, 'status'] = 'Blocked'
        df_server.to_excel(excel_file_path, index=False)
        current_card_status = df_server['status'].tolist()
        print("Updated card_status: ", current_card_status)

        account_status = f"Card Status Update - {card_number}. \n The card status for {card_number} is now Blocked."
        mail = sendmail(email, result, account_status)
        # print("email_id : ", email)
        # print("mail : ", mail)

        # Program stops and waits for new connection
        return False

    # Continue with the rest of your code or return a flag indicating to continue
    return True


def check_upi_status(email, upi_id, result):
    print("email : ", email)
    print("upi_id : ", upi_id)
    print("result : ", result)
    excel_file_path = 'payment_server.xlsx'
    df_server = pd.read_excel(excel_file_path)

    print("upi_id : ", upi_id)

    # Update the 'status' column based on the condition and specific upi_id
    mask = df_server['upi_id'] == upi_id
    print("upi_mask : ", mask)

    if result == 'Benign':
        if df_server.loc[mask, 'status'].iloc[0] == 'Active':
            print("df_server_1 : ", df_server)
            current_upi_id_status = df_server['status'].tolist()
            print("Updated upi_id_status_Active: ", current_upi_id_status)
            account_status = f"UPI ID Status Update - {upi_id}. \n The UPI ID status for {upi_id} is now Active."
            mail = sendmail(email, result, account_status)
        elif df_server.loc[mask, 'status'].iloc[0] == 'Blocked':
            print("df_server_2 : ", df_server)
            current_upi_id_status = df_server['status'].tolist()
            print("Updated upi_id_status_Active: ", current_upi_id_status)
            account_status = f"UPI ID Status Update - {upi_id}. \n The UPI ID status for {upi_id} is now Blocked."
            mail = sendmail(email, result, account_status)

    else:
        df_server.loc[mask, 'status'] = 'Blocked'
        df_server.to_excel(excel_file_path, index=False)
        current_upi_id_status = df_server['status'].tolist()
        print("Updated upi_id_status_Blocked: ", current_upi_id_status)

        account_status = f"UPI ID Status Update - {upi_id}. \n The UPI ID status for {upi_id} is now Blocked."
        mail = sendmail(email, result, account_status)
        # print("Phone Number : ", email)
        # print("Phone Number Status : ", mail)

        # Program stops and waits for new connection
        return False

    # Continue with the rest of your code or return a flag indicating to continue
    return True


while True:
    c, addr = s.accept()
    client_ip = addr[0]
    print()
    print('[CONNECTED]  > Connection got from ' + str(client_ip))
    print()

    msg = "Hello... send the packet"
    c.send(msg.encode("utf-8"))
    print("[MESSAGE SENT] > ", msg)
    print('')

    client_file = c.recv(20480)
    df = pd.read_csv(BytesIO(client_file))
    df_copy = df.copy(deep=True)
    df_copy = df_copy.iloc[:, -11:]

    # print("df_copy : ", df_copy)

    df_copy = df_copy.values.tolist()
    # print("df_copy : ", df_copy)

    payment_date = df_copy[0][0]
    # print("payment_date : ", payment_date)

    file_name = df_copy[0][1]
    # print("file_value : ", file_name)

    email = df_copy[0][2]
    email = "+"+str(email)
    # print("email : ", email)

    amount = df_copy[0][3]
    # print("amount : ", amount)

    payment = df_copy[0][4]
    # print("payment : ", payment)

    card_name = df_copy[0][5]
    # print("card_name : ", card_name)

    card_number = df_copy[0][6]
    # print("card_number : ", card_number)

    card_date = df_copy[0][7]
    # print("card_date : ", card_date)

    card_cvv = df_copy[0][8]
    # print("card_cvv : ", card_cvv)

    upi_name = df_copy[0][9]
    # print("upi_name : ", upi_name)

    upi_id = df_copy[0][10]
    # print("upi_id : ", upi_id)

    if payment == 'card':
        payment_method_check = check_ser_card_no(card_number)
        print("check_ser_card_stuts : ", payment_method_check)

    elif payment == 'upi':
        payment_method_check = check_ser_upi_id(upi_id)
        print("check_ser_upi_id : ", payment_method_check)

    if payment_method_check:
        # Continue with the rest of your code
        df.to_csv('in_folder/test.csv', index=False)
        print("[MESSAGE RECEIVED] >  file writing")
        print(" ")
        time.sleep(20)

        print("[MODEL PREDICTION] > Predicting...")
        result = attack_predict()
        insert_into_excel('ip_log.xlsx', client_ip, result)
        print("[MODEL PREDICTED RESULT] > ", result)

        if payment == 'card':
            card_upi_status = card_no_status(email, card_number, result)
            print("cur_card_no_status : ", card_upi_status)
        elif payment == 'upi':
            card_upi_status = check_upi_status(email, upi_id, result)
            print("upi_id_status : ", card_upi_status)

        excel_file_path_payment = 'payment_server.xlsx'
        df_server = pd.read_excel(excel_file_path_payment)

        mask_payment = (df_server['card_number'] == card_number) | (df_server['upi_id'] == upi_id)
        print("mask_payment : ", mask_payment)


        if card_upi_status and df_server.loc[mask_payment, 'status'].iloc[0] == 'Active':
            # msg = "share your email id !!"
            # c.send(msg.encode("utf-8"))
            # print('')
            # print('[MESSAGE SENT]   >', msg)

            email_id = df['email'].values[0]
            print('')
            print('[MESSAGE RECEIVED]', email_id)
            print('')
            print('[SENDING]  >  Sending result to', email_id)

            insert_into_payment("Payment.xlsx", payment_date, file_name, email, amount, payment,
                                card_name, card_number, card_date, card_cvv, upi_name, upi_id)

            print("Payment is Successfully Completed.")
            print("[LISTENING] Waiting for new connection ..")
            # Send a success response to the client
            c.send("success".encode("utf-8"))
            

        else:
            print("Account is Blocked.")
            print()
            print("[LISTENING] Waiting for new connection ...")
            # Send a failure response to the client
            c.send("blocked".encode("utf-8"))
    else:
        print("Invalid payment method")
        print()
        print("[LISTENING] Waiting for new connection ...")
        # Send a failure response to the client
        c.send("invalid_payment".encode("utf-8"))
