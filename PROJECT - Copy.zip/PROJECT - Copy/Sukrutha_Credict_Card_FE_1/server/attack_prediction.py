import pickle
from tensorflow.keras.models import load_model
import numpy as np
import pandas as pd
pd.set_option("display.max_columns", None)


with open(file="models/scaler.pkl", mode="rb") as file:
    scaler = pickle.load(file=file)


with open(file="models/selected_features.pkl", mode="rb") as file:
    selected_features = pickle.load(file=file)


model = load_model(
    "models/ArtificialNeuralNetwork_model.h5", compile=False)


class_labels = ['Benign', 'Brute Force', 'DDoS', 'DoS', 'PortScan']


# user_input = "user_input/file_6.csv"

def attack_predict():
    user_input = 'in_folder/test.csv'

    df = pd.read_csv(user_input)
    df = df[selected_features]
    scaled = scaler.transform(df.values)
    model_prediction = model.predict(scaled, verbose=0)

    class_index = model_prediction.argmax()
    class_label = class_labels[class_index]
    probability = model_prediction[0][class_index]

    print(class_index)
    print(class_label)
    print(probability)

    return class_label
