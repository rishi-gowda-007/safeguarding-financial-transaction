from flask import Flask, render_template, request
import socket
import os
import random
import csv
import pandas as pd
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'client'

port = 5005


class Client:
    def __init__(self, ip):
        self.content = None
        self.ip = ip
        self.port = port

    def send_file(self, date, filename, email, amount, payment_method, card_name, card_number, expiry_date, cvv_code, account_name, upi_id):
        file_path = "testing_data/" + filename

        df = pd.read_csv(file_path)

        data1 = {
            "date": date,
            "filename": filename,
            "email": email,
            "amount": amount,
            "payment_method": payment_method,
            "card_name": card_name,
            "card_number": card_number,
            "expiry_date": expiry_date,
            "cvv_code": cvv_code,
            "account_name": account_name,
            "upi_id": upi_id
        }

        df1 = pd.DataFrame(data1, index=[0])
        updated_content = pd.concat(objs=[df, df1], axis=1)

        # Convert the DataFrame to CSV string and then encode to bytes
        updated_content_bytes = updated_content.to_csv(
            index=False).encode("utf-8")

        return updated_content_bytes

    def connect(self, date,  filename, email, amount, payment_method, card_name, card_number, expiry_date, cvv_code, account_name, upi_id):
        try:
            s = socket.socket()
            s.connect((self.ip, self.port))
            s.recv(1024)

            content = self.send_file(date,
                                     filename, email, amount, payment_method, card_name, card_number, expiry_date, cvv_code, account_name, upi_id)
            s.send(content)
            # Receive the response from the server
            response = s.recv(2048).decode("utf-8")

            s.close()

            # Check the response and handle it accordingly
            if response == "success":
                print("Transaction successfully completed")
            elif response == "blocked":
                print("Account is blocked")
                # Display an error message on the frontend
            elif response == "invalid_payment":
                print("Invalid payment method")
                # Display an error message on the frontend

            return response

        except Exception as e:
            print("[ERROR] Oops something went wrong, check below error message")
            print("[ERROR MESSAGE] ", e)
            print("[IP ADDRESS] ", self.ip)
            print("[PORT] ", self.port)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/submit', methods=['POST'])
def submit():
    ip = request.form['ip']
    date = datetime.today()
    user_filename = request.form['filename']
    email = request.form['email']
    print("email : ", email)
    payment_method = request.form['payment-method']
    amount = request.form['amount']

    # Provide default value if not present
    card_name = request.form.get('card_name', '')
    card_number = request.form.get('card_number', '')
    expiry_date = request.form.get('expiry_date', '')
    cvv_code = request.form.get('cv_code', '')
    account_name = request.form.get('account_name', '')
    upi_id = request.form.get('upi_id', '')

    client = Client(ip)
    response = client.connect(date, user_filename, email, amount, payment_method, card_name,
                              card_number, expiry_date, cvv_code, account_name, upi_id)

    # Add this line for debugging
    print("Received response from server:", response)

    if response == "success":
        message = "Transaction successfully completed"
    elif response == "blocked":
        message = "Account is blocked"
    elif response == "invalid_payment":
        message = "Invalid payment method"
    else:
        message = "Invalid payment method or Account is blocked."

    return render_template('index.html', message=message)


if __name__ == '__main__':
    app.run(debug=True, port=2005)
